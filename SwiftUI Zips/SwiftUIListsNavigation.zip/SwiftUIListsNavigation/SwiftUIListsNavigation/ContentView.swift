//
//  ContentView.swift
//  SwiftUIListsNavigation
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct ContentView: View {
    let items = ["SwiftUI Basics", "Working with Lists", "Navigation in SwiftUI", "Advanced Animations"]
    
    var body: some View {
        NavigationStack {
            List(items, id: \.self) { item in
                NavigationLink(destination: DetailView(topic: item)) {
                    Text(item)
                        .padding(.vertical, 8)
                        .foregroundStyle(Color.blue)
                }
                .listRowBackground(Color.green)
            }
            .navigationTitle("Learning Topics")
        }
    }
}

#Preview {
    ContentView()
}
