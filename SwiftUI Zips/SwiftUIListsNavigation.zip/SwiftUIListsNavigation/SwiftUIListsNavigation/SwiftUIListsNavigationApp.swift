//
//  SwiftUIListsNavigationApp.swift
//  SwiftUIListsNavigation
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

@main
struct SwiftUIListsNavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
