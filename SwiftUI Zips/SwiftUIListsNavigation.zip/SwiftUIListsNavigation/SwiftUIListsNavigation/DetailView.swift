//
//  DetailView.swift
//  SwiftUIListsNavigation
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct DetailView: View {
    let topic: String
    
    var body: some View {
        VStack(spacing: 20) {
            Text(topic)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
                .background(Color.blue.opacity(0.2))
                .cornerRadius(15)
           
            
            Text("Here you can learn more about \(topic) in SwiftUI.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
        .navigationTitle(topic)
        .background(Color.gray)
    }
}


#Preview {
    DetailView(topic: "topic")
}
