//
//  ContentView.swift
//  SwiftuiSettingsDemo
//
//  Created by Noah Carpenter on 2024-11-05.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("username") private var username: String = ""
    @AppStorage("volumeLevel") private var volumeLevel: Double = 0.5
    @AppStorage("backgroundColor") private var backgroundColor: String = "White"
    
    //Background color options
    private let colorOptions: [String: Color] = ["White": .white, "Blue": .blue, "Green": .green, "Purple": .purple]
    
    init() {
        UITableView.appearance().backgroundColor = UIColor(Color.clear)
    }
    
    var body: some View {
        NavigationView{
            Form{
                //Section for Username input
                Section(header: Text("User Info")){
                    TextField("UserName", text: $username)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.vertical, 5)
                }
    //section for a volume slider
                Section(header: Text("Volume Slider")){
                    HStack{
                        Text("Volume")
                        Slider(value: $volumeLevel, in: 0...1, step: 0.01)
                        Text("\(Int(volumeLevel * 100))%")
                    }
                }
                // section for background colors
                Section(header: Text("Appearance")){
                    Picker("Background Color", selection: $backgroundColor){
                        ForEach(colorOptions.keys.sorted(), id: \.self) {
                            color in Text(color).tag(color)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
            }
         
        }
        .background(colorOptions[backgroundColor] ?? .black) //apply our custom background color
    }
}

#Preview {
    ContentView()
}
