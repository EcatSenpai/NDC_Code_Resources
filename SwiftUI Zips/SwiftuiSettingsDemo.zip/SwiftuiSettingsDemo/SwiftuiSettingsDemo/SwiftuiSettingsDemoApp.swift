//
//  SwiftuiSettingsDemoApp.swift
//  SwiftuiSettingsDemo
//
//  Created by Noah Carpenter on 2024-11-05.
//

import SwiftUI

@main
struct SwiftuiSettingsDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
