//
//  DetailView.swift
//  SwiftUIListsNavigationTests
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct DetailView: View {
    
    let topic: String
    
    var body: some View {

        VStack{
            Text(topic)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
            
            Text("Here you can learn more about \(topic) in swiftUI")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding()
            
        }
        .padding()
        .navigationTitle(topic)
        .background(Color.black.opacity(0.1))
        
        
    }
}

#Preview {
    DetailView(topic: "topic")
}
