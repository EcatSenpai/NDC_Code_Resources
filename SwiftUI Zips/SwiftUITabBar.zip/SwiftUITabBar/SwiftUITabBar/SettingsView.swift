//
//  SettingsView.swift
//  SwiftUITabBar
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Welcome to settings")
    }
}

#Preview {
    SettingsView()
}
