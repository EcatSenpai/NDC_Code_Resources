//
//  ProfileView.swift
//  SwiftUITabBar
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Welcome to your profile")
    }
}

#Preview {
    ProfileView()
}
