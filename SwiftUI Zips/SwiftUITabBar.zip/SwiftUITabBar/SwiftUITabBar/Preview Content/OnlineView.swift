//
//  OnlineView.swift
//  SwiftUITabBar
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct OnlineView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    OnlineView()
}
