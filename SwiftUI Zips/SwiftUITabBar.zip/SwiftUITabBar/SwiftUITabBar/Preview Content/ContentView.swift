//
//  ContentView.swift
//  SwiftUITabBar
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
            ProfileView()
                .tabItem{
                    Label("Profile", systemImage: "person.fill")
                }
            SettingsView()
                .tabItem{
                    Label("Settings", systemImage: "gear.circle.fill")
                }
            LeaderboardView()
                .tabItem{
                    Label("LeaderBoard", systemImage: "list.clipboard.fill")
                    
                }
            GameView()
                .tabItem{
                    Label("Games", systemImage: "gamecontroller.fill")
                }
            OnlineView()
                .tabItem{
                    Label("Online", systemImage:  "globe")
                }
        }
        .accentColor(.purple)
    }
}

#Preview {
    ContentView()
}
