//
//  DataLoader.swift
//  JsonExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import Foundation

class DataLoader {
    func loadFruits() -> [Fruit] {
        guard let url = Bundle.main.url(forResource: "FruitsJSON", withExtension: "json") else{
            print("Could not find fruits.JsonFile")
            return []
        }
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            let fruits = try decoder.decode([Fruit].self, from: data)
            return fruits
        } catch {
            print("Error decoding JSON: \(error)")
            return []
        }
    }
}
