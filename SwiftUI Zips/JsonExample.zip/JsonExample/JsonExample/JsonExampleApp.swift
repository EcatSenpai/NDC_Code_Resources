//
//  JsonExampleApp.swift
//  JsonExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

@main
struct JsonExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
