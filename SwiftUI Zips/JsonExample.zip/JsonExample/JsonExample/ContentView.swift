//
//  ContentView.swift
//  JsonExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct ContentView: View {
    @State private var fruits: [Fruit] = []
    var body: some View {
        NavigationView{
            List(fruits) { fruit in
                NavigationLink(destination: DetailView(fruit: fruit)) {
                    VStack{
                        Text(fruit.name)
                            .font(.headline)
                        Text(fruit.description)
                            .font(.subheadline)
                            .foregroundStyle(Color.purple)
                    }
                    .padding(.vertical, 10)
                }
            }
            .navigationTitle("Fruits")
            .onAppear{
                fruits = DataLoader().loadFruits() //load the data on appearance
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
