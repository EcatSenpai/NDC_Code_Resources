//
//  Fruit.swift
//  JsonExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import Foundation

struct Fruit: Codable, Identifiable {
    let id = UUID()
    let name: String
    let description: String
}
