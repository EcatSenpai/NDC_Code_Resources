//
//  DetailView.swift
//  JsonExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct DetailView: View {
    let fruit: Fruit
    var body: some View {
        VStack{
            Text(fruit.name)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 10)
            Text(fruit.description)
                .font(.body)
                .padding()
            
        }
        .navigationTitle(fruit.name)
    }
}

