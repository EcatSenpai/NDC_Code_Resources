//
//  ContentView.swift
//  PopoverExample
//
//  Created by Noah Carpenter on 2024-11-13.
//

import SwiftUI

struct ContentView: View {
    @State private var showAlert = false
    @State private var showPopover = false
    @State private var selectedItem: String? = nil
    @State private var items = ["apples", "bananas", "cherries"]
    
    
    
    var body: some View {
        VStack {
            List(items, id: \.self) { item in
                Text(item)
                    .onLongPressGesture {
                        selectedItem = item
                        showPopover = true
                    }
                    .swipeActions{
                        Button(role: .destructive) {
                            selectedItem = item
                            showAlert = true
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
            }
            .alert("Delte Item?", isPresented: $showAlert) {
                Button("Delete", role: .destructive) {
                    deleteItems(selectedItem)
                }
                Button("cancel", role: .cancel){}
            } message: {
                Text("Are you sure you want to delete \(selectedItem ?? "this item")")
            }
        }
        .popover(isPresented: $showPopover) {
            VStack(spacing: 20){
                Text(selectedItem ?? "Item Details")
                    .font(.title2)
                    .padding()
                Button("Close"){
                    showPopover = false
                }
                .padding()
                .background(Color.red)
                .foregroundStyle(Color.white)
            }
            .padding()
            .frame(width: 250, height: 250)
        }
        .padding()
        
    }
    private func deleteItems(_ item: String?) {
        if let item = item, let index = items.firstIndex(of: item){
            items.remove(at: index)
        }
    }
}

#Preview {
    ContentView()
}
