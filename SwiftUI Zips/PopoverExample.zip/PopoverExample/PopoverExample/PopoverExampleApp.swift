//
//  PopoverExampleApp.swift
//  PopoverExample
//
//  Created by Noah Carpenter on 2024-11-13.
//

import SwiftUI

@main
struct PopoverExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
