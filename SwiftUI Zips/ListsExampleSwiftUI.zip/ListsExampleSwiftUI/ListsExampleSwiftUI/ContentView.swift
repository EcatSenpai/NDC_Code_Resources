//
//  ContentView.swift
//  ListsExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct ContentView: View {
    @State private var toDoItems: [String] = ["Buy Groceries", "Play with the cat", "Go to the Gym", "Complete Homework"]
    @State private var newTask: String = ""
    var body: some View {
        NavigationView{
            VStack {
                // content will go here
                HStack{
                    TextField("New Task",  text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)
                    Button(action: addTask){
                        Image(systemName: "plus.circle.fill")
                            .foregroundStyle(Color.blue)
                            .font(.title)
                    }
                }
                List{
                    ForEach(toDoItems, id: \.self) { item in
                        Text(item)
                            .padding(.vertical, 8)
                    }
                    .onDelete(perform: deleteTask)
                }
            }
        }
        .padding()
    }
    private func addTask(){
        guard !newTask.isEmpty else {return}
        toDoItems.append(newTask)
        newTask = ""
    }
    private func deleteTask(at offsets: IndexSet){
        toDoItems.remove(atOffsets: offsets)
    }
}



#Preview {
    ContentView()
}
