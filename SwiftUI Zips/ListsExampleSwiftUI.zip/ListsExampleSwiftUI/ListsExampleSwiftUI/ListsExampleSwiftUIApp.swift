//
//  ListsExampleSwiftUIApp.swift
//  ListsExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

@main
struct ListsExampleSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
