//
//  APIExampleOpen_MeteoApp.swift
//  APIExampleOpen-Meteo
//
//  Created by Noah Carpenter on 2024-11-13.
//

import SwiftUI

@main
struct APIExampleOpen_MeteoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
