//
//  ContentView.swift
//  AminationsExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-10-29.
//

import SwiftUI

struct ContentView: View {
    
    @State private var isScaled = false
    @State private var showRectangle = false
    @State private var isLoading = false
    var body: some View {
        VStack(spacing: 40) {
            
            ZStack{
                
                Circle()
                    .stroke(
                        LinearGradient(gradient: Gradient(colors: [Color("SpinnerStart"), Color("SpinnerEnd")]),
                                       startPoint: .topLeading, endPoint: .bottomTrailing),
                        lineWidth: 5)
                    .foregroundStyle(Color.purple)
                    .frame(width: 50,height: 50)
                    .rotationEffect(Angle(degrees: isLoading ? 360 : 0))
                    .animation(Animation.linear(duration: 1).repeatForever(autoreverses: false), value: isLoading)
                
                   
                Button("Start Loading")
                {
                    isLoading.toggle()
                }
                
            }
            
            
            
            
//       Text("Tap the Circle")
//            
//            Circle()
//                .fill(Color.blue)
//                .frame(width: isScaled ? 150 : 100, height: isScaled ? 150 : 100)
//                .scaleEffect(isScaled ? 1.5 : 1.0)
//                .animation(.easeInOut(duration: 0.3), value: isScaled)
//            
//            Button("Animate") {
//                isScaled.toggle()
//            }
//            
//            Button("toggle rectangle"){
//                withAnimation(.easeInOut(duration: 0.5)){
//                    showRectangle.toggle()
//                }
//            }
//            if showRectangle {
//                Rectangle()
//                    .fill(Color.purple)
//                    .frame(width:200, height: 100)
//                    .transition(.slide)
//                    
//            }
            
            
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
