//
//  AppStorageExampleApp.swift
//  AppStorageExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

@main
struct AppStorageExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
