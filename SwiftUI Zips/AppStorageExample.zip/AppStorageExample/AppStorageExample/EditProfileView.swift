//
//  EditProfileView.swift
//  AppStorageExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct EditProfileView: View {
    @AppStorage("username") private var username: String = ""
    
    
    var body: some View {
        VStack{
            Text("Edit Username")
                .font(.largeTitle)
                .fontWeight(.bold)
            TextField("Enter your username", text: $username)
                .padding()
            Text("Username will be saved across launches")
                .font(.subheadline)
                .italic()
                .underline()
                .foregroundStyle(Color.blue)
        }
        .navigationTitle("Edit Profile")
    }
}

#Preview {
    EditProfileView()
}
