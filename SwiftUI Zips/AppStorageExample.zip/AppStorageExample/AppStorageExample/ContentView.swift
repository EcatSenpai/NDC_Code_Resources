//
//  ContentView.swift
//  AppStorageExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("username") private var username: String = ""
    @AppStorage("score") private var score: Int = 0
    
    
    
    var body: some View {
        NavigationView{
            VStack {
                Text("Welcome, \(username.isEmpty ? "Guest" : username)!")
                    .font(.largeTitle)
                    .padding()
                
                Text("Score \(score)")
                    .font(.title)
                    .padding()
                
                NavigationLink(destination: EditProfileView()) {
                    Text("Edit Profile")
                        .font(.headline)
                        .padding()
                        .background(Color.purple)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                Button(action: {
                    score += 1
                }) {
                    Text("Increase Score")
                        .font(.headline)
                        .padding()
                        .background(Color.green)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                Button(action: {
                    score -= 1
                }) {
                    Text("Decrease Score")
                        .font(.headline)
                        .padding()
                        .background(Color.red)
                        .foregroundStyle(Color.white)
                        .cornerRadius(25)
                }
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
