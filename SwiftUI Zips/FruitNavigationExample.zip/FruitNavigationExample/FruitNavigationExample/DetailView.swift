//
//  DetailView.swift
//  FruitNavigationExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct DetailView: View {
    let fruit: String
    var animationNamespace: Namespace.ID
    @Binding var selectedFruit: String?
    
    var body: some View {
     // display the fruit name and matched geomerty effect
        Text(fruit)
            .font(.largeTitle)
            .fontWeight(.bold)
            .padding()
            .frame(maxWidth: .infinity, minHeight: 300)
            .background(Color.orange)
            .foregroundStyle(Color.white)
            .matchedGeometryEffect(id: fruit, in: animationNamespace)
            .onTapGesture {
                //clear the slection and go back
                withAnimation(.easeIn(duration: 0.5)) {
                    selectedFruit = nil
                }
            }
            .background(Color(.systemBackground)) // its going to attempt to avoid any flashing issues
            .navigationBarBackButtonHidden(true) // hide the default back button
    }

}

