//
//  ContentView.swift
//  FruitNavigationExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct ContentView: View {
    let fruits = ["Apple", "Banana", "Cherry", "Date", "Elderberry"] // our array of fruits
    @Namespace private var animationNamespace
    @State private var selectedFruit: String? = nil
    var body: some View {

            ScrollView{
                VStack (spacing: 20){
                    ForEach(fruits, id: \.self) { fruit in
                        NavigationLink(destination: DetailView(fruit: fruit, animationNamespace: animationNamespace, selectedFruit: $selectedFruit),
                                       tag: fruit,
                                       selection:  $selectedFruit
                        ) {
                            FruitCardView(fruit: fruit, animationNamespace: animationNamespace)
                        }
                        .buttonStyle(PlainButtonStyle())// remove default button styling
                    }
            }
            .padding()
        }
    }
}


#Preview {
    ContentView()
}
