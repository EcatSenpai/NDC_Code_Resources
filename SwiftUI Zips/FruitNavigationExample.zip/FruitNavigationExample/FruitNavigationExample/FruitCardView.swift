//
//  FruitCardView.swift
//  FruitNavigationExample
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct FruitCardView: View {
    let fruit: String
    var animationNamespace: Namespace.ID
    
    var body: some View {
        Text(fruit)
            .font(.title)
            .fontWeight(.bold)
            .padding()
            .frame(maxWidth: .infinity, maxHeight: 100)
            .background(Color.orange)
            .foregroundStyle(Color.white)
            .cornerRadius(25)
            .matchedGeometryEffect(id: fruit, in: animationNamespace)
    }
}


