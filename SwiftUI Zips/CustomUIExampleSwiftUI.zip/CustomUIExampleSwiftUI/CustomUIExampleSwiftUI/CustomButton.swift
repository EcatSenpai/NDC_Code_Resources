//
//  CustomButton.swift
//  CustomUIExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-10-31.
//

import SwiftUI

struct CustomButton: View {
    var title: String // Button text
    var action: () -> Void //action triggered when button is tapped
    
    
    var body: some View {
        Button(action: action){
            
            Text(title) //set the custom title
                .font(.headline) // sets the text font to headline
                .padding() // adds padding for a larger tap area
                .frame(maxWidth: .infinity) // increase button size
                .background(Color.purple) // add background color to button
                .foregroundStyle(Color.white) // change the color of the text on the button
                .cornerRadius(25) // Round the corners of the button
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .stroke(Color.blue.opacity(1), lineWidth: 5)
                )
                .shadow(color: Color.gray.opacity(0.5), radius: 5, x: 0, y:5 )// adds a shadow for depth
        }
    }
}


