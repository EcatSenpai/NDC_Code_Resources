//
//  DetailView.swift
//  CustomUIExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-10-31.
//

import SwiftUI

struct DetailView: View {
    var body: some View {
        Text("Welcome to Detail View")
    }
}

#Preview {
    DetailView()
}
