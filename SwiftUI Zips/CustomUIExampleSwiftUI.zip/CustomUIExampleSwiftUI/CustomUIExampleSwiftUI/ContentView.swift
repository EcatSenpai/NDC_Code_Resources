//
//  ContentView.swift
//  CustomUIExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-10-31.
//

import SwiftUI

struct ContentView: View {
    @State private var username = ""
    
    var body: some View {
        NavigationStack{
            ZStack {
                GradientBackground() // adds animated gradient to our contentView
                VStack {
                    
                    Image("profileImage") // displays image from assets
                        .resizable() // allow for resizing to fir the frame
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())//clip our image to a circular shape
                        .overlay(
                            Circle().stroke(Color.purple, lineWidth: 5)
                        )
                        .shadow(radius: 5)
                    
                    
                    Text("Home Page")
                    NavigationLink(destination: DetailView()) {
                        CustomButton(title: "Go to Details") {}
                    }
                    
                    CustomTextField(text: $username, placeholder: "Enter your Name")
                    
                }
                .padding()
            }
        }
    }
}

#Preview {
    ContentView()
}
