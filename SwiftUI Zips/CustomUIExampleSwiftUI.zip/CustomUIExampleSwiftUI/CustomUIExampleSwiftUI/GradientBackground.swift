//
//  GradientBackground.swift
//  CustomUIExampleSwiftUI
//
//  Created by Noah Carpenter on 2024-10-31.
//

import SwiftUI

struct GradientBackground: View {
    @State private var animateGradient = false // Track the animation state for gradient movement
    var body: some View {
        LinearGradient(colors: [Color.purple, Color.orange], startPoint: animateGradient ? .topLeading : .bottomTrailing, endPoint: animateGradient ? .bottomTrailing : .topLeading) // gradient from purple to orange
            .edgesIgnoringSafeArea(.all) // extend gradient to cover entire screen
            .onAppear{
                // toggle gradient animation with smooth transistions
                withAnimation(Animation.easeInOut(duration: 3).repeatForever(autoreverses: true)){
                    animateGradient.toggle()
                }
            }


    }
}

#Preview {
    GradientBackground()
}
