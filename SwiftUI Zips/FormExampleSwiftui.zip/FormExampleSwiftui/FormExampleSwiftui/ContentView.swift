//
//  ContentView.swift
//  FormExampleSwiftui
//
//  Created by Noah Carpenter on 2024-11-06.
//

import SwiftUI

struct ContentView: View {
    @State private var  username: String = ""
    @State private var notificationsEnabled: Bool = false
    @State private var volume: Double = 50.0
    @State private var selectedTheme: String = "Light"
    
    let themes = ["Light", "Dark", "System"]
    
    var body: some View {
        ZStack{
            Color(.systemRed)
                .edgesIgnoringSafeArea(.all)
            
            NavigationView{
                Form{
                    Section(header: Text("Profile settings")){    //profile settings will go here
                        TextEditor( text: $username)
                            .frame(height: 100)
                            .textFieldStyle(PlainTextFieldStyle())
                            .font(.body)
                        
                    }
                    Section(header: Text("Preferences")){
                        //preferences will go here
                        Toggle("Enable Notifications", isOn: $notificationsEnabled)
                        
                        Slider(value: $volume, in: 0...100, step: 1)
                        Text("Volume")
                        Text("Current Volume \(Int(volume))")
                        
                        Picker("Select Theme", selection: $selectedTheme){
                            ForEach(themes, id: \.self) { theme in
                                Text(theme)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                    }
                    Section(header: Text("Preview")){
                        Text("Username: \(username)")
                        Text("Notifications: \(notificationsEnabled ? "On" : "Off")")
                        Text("Current Volume \(Int(volume))")
                        Text("Theme: \(selectedTheme)")
                        
                    }
                    .background(Color.clear)
                }
              
                .navigationTitle("Settings")
            }
          
        }
    }
}

#Preview {
    ContentView()
}
