//
//  SwiftUICounterApp.swift
//  SwiftUICounter
//
//  Created by Noah Carpenter on 2024-10-28.
//

import SwiftUI

@main
struct SwiftUICounterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
