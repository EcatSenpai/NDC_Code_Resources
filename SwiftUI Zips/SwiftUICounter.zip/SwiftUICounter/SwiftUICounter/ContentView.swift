//
//  ContentView.swift
//  SwiftUICounter
//
//  Created by Noah Carpenter on 2024-10-28.
//

import SwiftUI

class ScoreModel: ObservableObject{
    @Published var score = 0
}

struct ContentView: View {
    @ObservedObject var scoreModel = ScoreModel()
    
    var body: some View {
        NavigationStack{
            VStack {
                
                Text("Score \(scoreModel.score)")
                    .font(.largeTitle)
                
                Button(action: {
                    scoreModel.score += 1
                })
                {
                    Text("Increase Score")
                        .padding()
                        .background(Color.blue)
                        .foregroundStyle(Color.white)
                        .cornerRadius(20)
                }
                
                NavigationLink(destination: ScoreDetailView(scoreModel: scoreModel)) {
                    Text("Go to Score Detail")
                        .padding()
                        .background(Color.green)
                        .foregroundStyle(Color.white)
                        .cornerRadius(20)
                }
                
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
