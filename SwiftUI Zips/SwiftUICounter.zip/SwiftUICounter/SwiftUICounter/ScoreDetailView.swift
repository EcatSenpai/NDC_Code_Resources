//
//  ScoreDetailView.swift
//  SwiftUICounter
//
//  Created by Noah Carpenter on 2024-10-28.
//

import SwiftUI

struct ScoreDetailView: View {
    
    @ObservedObject var scoreModel: ScoreModel
    
    var body: some View {
        VStack {
            
            Text("score detail view")
                .font(.title)
            
            Text("Current score \(scoreModel.score)")
                .font(.largeTitle)
            
            Button(action: {
                scoreModel.score += 1
            })
            {
                Text("Increase Score")
                    .padding()
                    .background(Color.blue)
                    .foregroundStyle(Color.white)
                    .cornerRadius(20)
            }
            
            
        }
        
        
    }
}

#Preview {
    let sampleScoreModel = ScoreModel()
    ScoreDetailView(scoreModel: sampleScoreModel)
}
