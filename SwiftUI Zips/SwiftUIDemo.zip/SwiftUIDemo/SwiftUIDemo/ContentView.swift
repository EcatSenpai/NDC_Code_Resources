//
//  ContentView.swift
//  SwiftUIDemo
//
//  Created by Noah Carpenter on 2024-10-26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            
            Image(systemName: "trash.fill")
                .imageScale(.large)
            HStack{
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                Text("Hello, SwiftUI!")
                    .font(.largeTitle)
                    .foregroundStyle(Color.red)
                    .padding()
                    .background(Color.gray)
                    .cornerRadius(25)
            }

            
        }
        
        HStack {
            
            Text("Left")
                .font(.largeTitle)
            Text("Middle")
                .font(.largeTitle)
            Text("Right")
                .font(.largeTitle)
            
            
        }
        
        ZStack{
            
            Color.gray.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
            
            Text("Swift UI Stacks")
                .font(.largeTitle)
                .padding()
                .background(Color.blue)
            
            
        }
        
        
        .padding()
    }
}

#Preview {
    ContentView()
}
