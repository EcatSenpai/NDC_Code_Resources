//
//  SwiftUIDemoApp.swift
//  SwiftUIDemo
//
//  Created by Noah Carpenter on 2024-10-26.
//

import SwiftUI

@main
struct SwiftUIDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
