//
//  SwiftUIStacksApp.swift
//  SwiftUIStacks
//
//  Created by Noah Carpenter on 2024-10-28.
//

import SwiftUI

@main
struct SwiftUIStacksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
