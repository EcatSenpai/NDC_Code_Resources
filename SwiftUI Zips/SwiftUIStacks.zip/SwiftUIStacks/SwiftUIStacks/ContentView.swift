//
//  ContentView.swift
//  SwiftUIStacks
//
//  Created by Noah Carpenter on 2024-10-28.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 20) {
          // profile card content goes in here
            ZStack{
                
                Circle()
                    .fill(Color.blue)
                    .frame(width: 120, height: 120)
                
                    Image("bob-barker")
                    .resizable()
                    .scaledToFit()
                    .frame(width:100, height:100)
                    .foregroundStyle(Color.white)
                    .cornerRadius(50)
            }
            
            VStack(spacing: 10) {
                
                Text("Bob Barker")
                    .font(.title)
                    .fontWeight(.bold)
                
                Text("iOS Developer and SwiftUI Enthusiast")
                    .font(.subheadline)
                    .foregroundStyle(Color.green)
                    .multilineTextAlignment(.center)
                
            }
            
            HStack(spacing:20){
                
                Button(action: {
                    print("Button Pressed")
                }) {
                    Image(systemName: "message.fill")
                        .font(.title)
                        .foregroundStyle(Color.green)
                    
                }
                
                Button(action: {
                    print("Phone Pressed")
                }) {
                    Image(systemName: "phone.fill")
                        .font(.title)
                        .foregroundStyle(Color.blue)
                    
                }
                
                
            }
            
            
            
        }
        .padding()
        .background(Color.gray)
        .cornerRadius(10)
        .shadow(radius: 10)
    }
}

#Preview {
    ContentView()
}
